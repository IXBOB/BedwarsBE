# BedwarsBE
</br>Minecraft Bedrock Edition BedWar, created by IXBOB
</br> Applicable version: 1.18.73
</br>
</br>Using the MIT open source license
</br>International version github: https://github.com/IXBOB/BedwarsBE
</br>China version github: https://github.com/IXBOB/BedwarsBE_CN
</br>Change log: https://ixbob.github.io/changelog/map1.html
</br>
</br>Discord: https://discord.gg/NFdcTX3NPz
